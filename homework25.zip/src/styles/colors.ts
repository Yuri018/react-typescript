interface Colors {
    primary: string;
}

export const colors: Colors = {
    primary: "rgb(26, 35, 53)",
}