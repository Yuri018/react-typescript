export { default as LikeIcon } from "./like.png";

export { default as DislikeIcon } from "./dislike.png";