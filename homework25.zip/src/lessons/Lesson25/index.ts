import Lesson25 from "./Lesson25";

export default Lesson25;