import Homework22 from "./Homework22";

export default Homework22;