import HomeWork21 from "./HomeWork21";

export default HomeWork21;