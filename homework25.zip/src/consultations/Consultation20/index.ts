import Consutation20 from "./Consultation20";

export default Consutation20;